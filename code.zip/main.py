from __future__ import annotations

import csv
from pathlib import Path
from collections import Counter
from decimal import Decimal, InvalidOperation
from datetime import date, datetime, timedelta


# ============================================================
# PATHS
# ============================================================

ROOT = Path(__file__).resolve().parents[1]
DATASET_DIR = ROOT / "dataset"
MEDIA_DIR = DATASET_DIR / "media" / "images"

# ============================================================
# RECOVERED AMOUNTS FROM SUPPLIED IMAGES
# ============================================================
#
# The challenge intentionally contains a small number of
# financial events whose CSV amount field is blank.
#
# For those events, images.csv links the event to a supplied
# image in dataset/media/images/. The amounts below were
# recovered from those supplied documents.
#
# These are NOT guesses. They are the amounts explicitly shown
# on the corresponding source documents.
#
# Structure:
#     event_id -> (amount, currency)
#
# Keep this mapping isolated from the financial decision logic.
# ============================================================

IMAGE_RECOVERED_AMOUNTS: dict[str, tuple[Decimal, str]] = {
    "event_253": (Decimal("4365000"), "IDR"),
    "event_1442": (Decimal("100000"), "INR"),
    "event_1545": (Decimal("41772"), "INR"),
    "event_1700": (Decimal("2854"), "INR"),
    "event_1786": (Decimal("704.05"), "INR"),
    "event_3051": (Decimal("1995"), "INR"),
    "event_3231": (Decimal("8528.10"), "INR"),
    "event_4535": (Decimal("15339"), "INR"),
    "event_5170": (Decimal("723"), "INR"),
    "event_6033": (Decimal("79679.26"), "INR"),
    "event_6859": (Decimal("3650"), "INR"),
    "event_7307": (Decimal("33.50"), "USD"),
    "event_7941": (Decimal("2298"), "INR"),
    "event_9421": (Decimal("4593"), "INR"),
    "event_9806": (Decimal("9968"), "INR"),
    "event_10521": (Decimal("393.22"), "INR"),
}

# ============================================================
# REQUIRED OUTPUT COLUMNS
# ============================================================

OUTPUT_COLUMNS = [
    "request_id",
    "amount_safe_to_pay",
    "affordability_status",
    "recommended_payment_method",
    "payment_plan",
    "earliest_date_for_full_payment",
    "spending_changes_needed",
    "decision_explanation",
]


# ============================================================
# CSV HELPERS
# ============================================================

def load_csv(filename: str) -> list[dict[str, str]]:
    """Load a CSV file from the dataset directory."""
    path = DATASET_DIR / filename

    if not path.exists():
        raise FileNotFoundError(f"Required dataset file not found: {path}")

    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def parse_decimal(value: str | None) -> Decimal | None:
    """Convert a CSV value to Decimal, preserving blanks as None."""
    if value is None:
        return None

    value = value.strip()

    if value == "":
        return None

    try:
        return Decimal(value)
    except InvalidOperation as exc:
        raise ValueError(f"Invalid numeric value: {value!r}") from exc


def parse_date(value: str | None) -> date | None:
    """Convert YYYY-MM-DD text to a date."""
    if value is None:
        return None

    value = value.strip()

    if value == "":
        return None

    return datetime.strptime(value, "%Y-%m-%d").date()


# ============================================================
# DATA LOADING
# ============================================================

def load_datasets() -> dict[str, list[dict[str, str]]]:
    """Load every dataset required by the challenge."""

    return {
        "requests": load_csv("requests.csv"),
        "financial_profiles": load_csv("financial_profiles.csv"),
        "financial_events": load_csv("financial_events.csv"),
        "request_payment_options": load_csv("request_payment_options.csv"),
        "messages": load_csv("messages.csv"),
        "images": load_csv("images.csv"),
        "exchange_rates": load_csv("exchange_rates.csv"),
    }


# ============================================================
# VALIDATION
# ============================================================

def validate_output_columns() -> None:
    """Ensure the required output schema has not been accidentally changed."""

    expected = [
        "request_id",
        "amount_safe_to_pay",
        "affordability_status",
        "recommended_payment_method",
        "payment_plan",
        "earliest_date_for_full_payment",
        "spending_changes_needed",
        "decision_explanation",
    ]

    if OUTPUT_COLUMNS != expected:
        raise AssertionError("Output column schema does not match the challenge.")


def validate_dataset_counts(data: dict[str, list[dict[str, str]]]) -> None:
    """Basic sanity checks for the supplied challenge dataset."""

    expected_counts = {
        "requests": 250,
        "financial_profiles": 275,
        "financial_events": 25342,
        "request_payment_options": 790,
        "messages": 215,
        "images": 16,
        "exchange_rates": 134,
    }

    for name, expected_count in expected_counts.items():
        actual_count = len(data[name])

        if actual_count != expected_count:
            raise AssertionError(
                f"{name}: expected {expected_count} rows, found {actual_count}"
            )


def payment_dates_for_option(option):
    first_date = option["first_payment_date"]
    count = int(option["number_of_payments"])
    frequency_days = option["payment_frequency_days"]

    if first_date is None or count <= 0:
        return []

    dates = []

    for i in range(count):
        if frequency_days is None or frequency_days <= 0:
            d = first_date
        else:
            d = first_date + timedelta(
                days=frequency_days * i
            )

        dates.append(d)

    return dates


def build_forecast_with_payments(
    request,
    profile,
    events_by_user,
    recurring_streams,
    messages_by_user,
    fx_index,
    payments,
    spending_changes=None,
):
    """
    Build the normal 90-day forecast and apply hypothetical payment(s)
    and optional recurring-spending changes.
    """
    forecast = build_daily_forecast(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
    )

    spending_changes = spending_changes or []

    stop_ids = set()
    reduce_map = {}

    for change in spending_changes:
        if change["action"] == "stop":
            stop_ids.add(change["event_id"])
        elif change["action"] == "reduce":
            reduce_map[change["event_id"]] = change["amount"]

    # Apply recurring-spending changes to the forecast.
    if stop_ids or reduce_map:
        user_id = request["user_id"]

        # Identify recurring source events represented in the forecast.
        for day, balance in list(forecast.items()):
            pass

        # Rebuild balances from forecast deltas so changes can be applied
        # consistently to future occurrences.
        rebuilt = {}
        running = profile["current_balance"]

        forecast_events = get_forecast_events(
            request=request,
            events_by_user=events_by_user,
            recurring_streams=recurring_streams,
            messages_by_user=messages_by_user,
            fx_index=fx_index,
        )

        daily_deltas = {}

        for event in forecast_events:
            if event.get("user_id") != user_id:
                continue

            event_date = event_forecast_date(event)
            if event_date is None:
                continue
            if event_date < request["request_date"]:
                continue
            if event_date > request["request_date"] + timedelta(days=90):
                continue

            signed = event_signed_amount(event)

            source_id = (
                event.get("linked_event_id")
                or event.get("source_event_id")
                or event.get("event_id")
            )

            if source_id in stop_ids:
                signed = Decimal("0")

            elif source_id in reduce_map and signed < 0:
                original_abs = abs(signed)
                new_abs = min(original_abs, reduce_map[source_id])
                signed = -new_abs

            daily_deltas[event_date] = (
                daily_deltas.get(event_date, Decimal("0")) + signed
            )

        for d in sorted(forecast):
            if d == request["request_date"]:
                running = profile["current_balance"]
            running += daily_deltas.get(d, Decimal("0"))

            for payment_date, payment_amount in payments:
                if d == payment_date:
                    running -= payment_amount

            rebuilt[d] = running

        forecast = rebuilt

    else:
        # Normal forecast, only subtract hypothetical payments.
        for payment_date, payment_amount in payments:
            if payment_date not in forecast:
                continue
            for d in forecast:
                if d >= payment_date:
                    forecast[d] -= payment_amount

    return forecast


def is_safe_with_payments(
    request,
    profile,
    events_by_user,
    recurring_streams,
    messages_by_user,
    fx_index,
    payments,
    spending_changes=None,
):
    forecast = build_forecast_with_payments(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
        payments=payments,
        spending_changes=spending_changes,
    )

    minimum_balance = profile["minimum_balance_to_keep"]

    return all(balance >= minimum_balance for balance in forecast.values())


def find_earliest_full_payment_date(
    request,
    profile,
    events_by_user,
    recurring_streams,
    messages_by_user,
    fx_index,
):
    """
    Return the first date on which the full requested amount can
    be paid safely without changing optional spending.

    The request date itself MUST be tested first.
    """
    requested_amount = request["requested_amount"]
    request_date = request["request_date"]

    if requested_amount is None or request_date is None:
        return None

    forecast_end = request_date + timedelta(days=90)

    # Always test TODAY / request date first.
    if is_safe_with_payments(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
        payments=[(request_date, requested_amount)],
    ):
        return request_date

    # Then search forward one day at a time.
    current_date = request_date + timedelta(days=1)

    while current_date <= forecast_end:
        if is_safe_with_payments(
            request=request,
            profile=profile,
            events_by_user=events_by_user,
            recurring_streams=recurring_streams,
            messages_by_user=messages_by_user,
            fx_index=fx_index,
            payments=[(current_date, requested_amount)],
        ):
            return current_date

        current_date += timedelta(days=1)

    return None

def format_money(value):
    if value is None:
        return ""
    value = Decimal(value).quantize(Decimal("0.01"))
    text = format(value, "f")
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text


def format_plan(payments):
    return "|".join(
        f"{payment_date.isoformat()}:{format_money(amount)}"
        for payment_date, amount in payments
    )


def spending_change_candidates(request, profile, events_by_user):
    """
    Return flexible recurring expense events that the user permits us
    to stop/reduce.
    """
    allowed_categories = set(
        x.strip().lower()
        for x in profile.get("willing_to_reduce_or_stop_categories", [])
        if x.strip()
    )

    candidates = []

    for event in events_by_user.get(request["user_id"], []):
        if not is_financially_active_event(event):
            continue

        if event["event_type"] not in {"expense", "subscription"}:
            continue

        if event["direction"] != "outflow":
            continue

        if event["flexibility"] not in {
            "reducible",
            "reducible_or_stoppable",
            "stoppable",
        }:
            continue

        category = (event.get("category") or "").strip().lower()

        if allowed_categories and category not in allowed_categories:
            continue

        amount = event_home_currency_amount(event)

        if amount is None or amount <= 0:
            continue

        candidates.append(event)

    # Largest recurring expense first gives the greatest safety improvement.
    candidates.sort(
        key=lambda e: abs(event_home_currency_amount(e) or Decimal("0")),
        reverse=True,
    )

    # Avoid duplicate occurrences of the same recurring stream.
    seen = set()
    unique = []

    for event in candidates:
        key = recurring_group_key(event)
        if key in seen:
            continue
        seen.add(key)
        unique.append(event)

    return unique


def find_spending_changes_for_full_payment(
    request,
    profile,
    events_by_user,
    recurring_streams,
    messages_by_user,
    fx_index,
    earliest_full_date,
):
    """
    Search up to three allowed recurring-spending changes.
    Prefer no change, then one change, then two, then three.
    """
    candidates = spending_change_candidates(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
    )[:20]

    if not candidates:
        return None

    requested_amount = request["requested_amount"]

    # Try combinations in increasing number of changes.
    from itertools import combinations

    for count in range(1, 4):
        for combo in combinations(candidates, count):
            changes = []

            for event in combo:
                event_id = event["event_id"]
                amount = event_home_currency_amount(event)

                if event["flexibility"] in {
                    "stoppable",
                    "reducible_or_stoppable",
                }:
                    changes.append({
                        "action": "stop",
                        "event_id": event_id,
                    })
                else:
                    # Reducible-only event: reduce by half, but never below
                    # its declared minimum.
                    minimum = event.get("minimum_allowed_amount")
                    if minimum is None:
                        minimum = Decimal("0")

                    new_amount = max(
                        minimum,
                        (amount / Decimal("2")).quantize(Decimal("0.01")),
                    )

                    if new_amount >= amount:
                        continue

                    changes.append({
                        "action": "reduce",
                        "event_id": event_id,
                        "amount": new_amount,
                    })

            if not changes:
                continue

            if is_safe_with_payments(
                request,
                profile,
                events_by_user,
                recurring_streams,
                messages_by_user,
                fx_index,
                [(earliest_full_date, requested_amount)],
                changes,
            ):
                return changes

    return None


def choose_payment_option(
    request,
    profile,
    payment_options_by_request,
    events_by_user,
    recurring_streams,
    messages_by_user,
    fx_index,
):
    options = payment_options_by_request.get(request["request_id"], [])

    eligible = []

    for option in options:
        method = (option["payment_method"] or "").strip().lower()

        if method not in profile["payment_methods_user_will_consider"]:
            continue

        dates = payment_dates_for_option(option)

        if not dates:
            continue

        payments = [
            (d, option["payment_amount"])
            for d in dates
        ]

        # Must complete by desired completion date.
        if dates[-1] > request["desired_completion_date"]:
            continue

        if not is_safe_with_payments(
            request,
            profile,
            events_by_user,
            recurring_streams,
            messages_by_user,
            fx_index,
            payments,
        ):
            continue

        eligible.append((option, dates, payments))

    if not eligible:
        return None

    # Ranking:
    # 1 complete by deadline (already enforced)
    # 2 no spending changes (already enforced)
    # 3 minimize total amount paid
    # 4 start earlier
    # 5 fewer payments
    # 6 lowest payment_option_id
    eligible.sort(
        key=lambda item: (
            item[0]["total_payable_amount"],
            item[1][0],
            len(item[1]),
            item[0]["payment_option_id"],
        )
    )

    return eligible[0]


def solve_request(
    request,
    profile,
    events_by_user,
    recurring_streams,
    messages_by_user,
    fx_index,
    payment_options_by_request,
):
    requested_amount = request["requested_amount"]
    request_date = request["request_date"]

    safe_amount = calculate_amount_safe_to_pay(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
    )

    earliest_full = find_earliest_full_payment_date(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
    )

    # Nothing can be safely paid now and full payment cannot become safe
    # before the deadline.
    if safe_amount <= 0 and earliest_full is None:
        return {
            "request_id": request["request_id"],
            "amount_safe_to_pay": format_money(safe_amount),
            "affordability_status": "not_affordable",
            "recommended_payment_method": "not_recommended",
            "payment_plan": "none",
            "earliest_date_for_full_payment": "",
            "spending_changes_needed": "none",
            "decision_explanation": (
                "Full payment cannot be made safely by the desired "
                "completion date without violating the minimum balance."
            ),
        }

    # Full payment is safe today.
    if safe_amount >= requested_amount:
        # Full payment today is itself a valid candidate.
        # It has one payment, starts on the request date, and requires
        # no spending changes. Do not automatically prefer an
        # installment option merely because one exists.
        if is_safe_with_payments(
            request,
            profile,
            events_by_user,
            recurring_streams,
            messages_by_user,
            fx_index,
            payments=[(request_date, requested_amount)],
            spending_changes=[],
        ):
            return {
                "request_id": request["request_id"],
                "amount_safe_to_pay": safe_amount,
                "affordability_status": "affordable_now",
                "recommended_payment_method": "full_payment",
                "payment_plan": format_plan(
                    [(request_date, requested_amount)]
                ),
                "earliest_date_for_full_payment": request_date.isoformat(),
                "spending_changes_needed": "none",
                "decision_explanation": (
                    f"The full requested amount of "
                    f"{format_money(requested_amount)}"
                    f"is safe to pay on the request date while maintaining "
                    f"the required minimum balance and protected expenses."
                ),
            }
    # Partial payment.
    if (
        request["allows_partial_payment"]
        and safe_amount > 0
        and safe_amount < requested_amount
        and earliest_full is not None
        and earliest_full <= request["desired_completion_date"]
    ):
        remainder = requested_amount - safe_amount

        return {
            "request_id": request["request_id"],
            "amount_safe_to_pay": format_money(safe_amount),
            "affordability_status": "affordable_with_plan",
            "recommended_payment_method": "partial_payment",
            "payment_plan": format_plan([
                (request_date, safe_amount),
                (earliest_full, remainder),
            ]),
            "earliest_date_for_full_payment": earliest_full.isoformat(),
            "spending_changes_needed": "none",
            "decision_explanation": (
                "A partial payment is safe today and the remaining balance "
                "can be paid in full on the earliest safe date before the deadline."
            ),
        }

    # Wait is preferable when full payment becomes safe before the deadline.
    if earliest_full is not None and earliest_full <= request["desired_completion_date"]:
        return {
            "request_id": request["request_id"],
            "amount_safe_to_pay": format_money(safe_amount),
            "affordability_status": "affordable_later",
            "recommended_payment_method": "wait",
            "payment_plan": format_plan([(earliest_full, requested_amount)]),
            "earliest_date_for_full_payment": earliest_full.isoformat(),
            "spending_changes_needed": "none",
            "decision_explanation": (
                "The full amount is not safe today, but becomes safe on "
                "the earliest date before the desired completion date."
            ),
        }

    # Try up to three spending changes to make full payment possible.
    spending_changes = find_spending_changes_for_full_payment(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
        earliest_full_date=request["desired_completion_date"],
    )

    if spending_changes:
        formatted_changes = []

        for change in spending_changes:
            if change["action"] == "stop":
                formatted_changes.append(f"stop:{change['event_id']}")
            else:
                formatted_changes.append(
                    f"reduce_to:{change['event_id']}:{format_money(change['amount'])}"
                )

        # Find earliest date after applying the changes.
        changed_date = request_date
        while changed_date <= request["desired_completion_date"]:
            if is_safe_with_payments(
                request,
                profile,
                events_by_user,
                recurring_streams,
                messages_by_user,
                fx_index,
                [(changed_date, requested_amount)],
                spending_changes,
            ):
                return {
                    "request_id": request["request_id"],
                    "amount_safe_to_pay": format_money(safe_amount),
                    "affordability_status": "affordable_with_plan",
                    "recommended_payment_method": "full_payment",
                    "payment_plan": format_plan([(changed_date, amount)]),
                    "earliest_date_for_full_payment": (
                        earliest_full.isoformat() if earliest_full else ""
                    ),
                    "spending_changes_needed": "|".join(formatted_changes),
                    "decision_explanation": (
                        "Full payment requires allowed recurring spending "
                        "changes to maintain the required minimum balance."
                    ),
                }

            changed_date += timedelta(days=1)

    return {
        "request_id": request["request_id"],
        "amount_safe_to_pay": format_money(safe_amount),
        "affordability_status": "not_affordable",
        "recommended_payment_method": "not_recommended",
        "payment_plan": "none",
        "earliest_date_for_full_payment": "",
        "spending_changes_needed": "none",
        "decision_explanation": (
            "The requested amount cannot be paid safely by the desired "
            "completion date under the available payment options."
        ),
    }

# ============================================================
# OUTPUT HELPERS
# ============================================================

def write_output(rows: list[dict[str, str]]) -> None:
    """Write the final required output.csv."""

    output_path = ROOT / "output.csv"

    with output_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=OUTPUT_COLUMNS,
            extrasaction="raise",
        )

        writer.writeheader()
        writer.writerows(rows)

# ============================================================
# NORMALIZED DATA
# ============================================================

def split_pipe_list(value: str | None) -> list[str]:
    """Convert pipe-separated CSV fields into clean lists."""

    if value is None:
        return []

    value = value.strip()

    if not value:
        return []

    return [
        item.strip()
        for item in value.split("|")
        if item.strip()
    ]


def normalize_profiles(
    rows: list[dict[str, str]],
) -> dict[str, dict]:
    """Convert financial profiles into user_id -> profile mappings."""

    profiles = {}

    for row in rows:
        user_id = row["user_id"]

        profiles[user_id] = {
            "user_id": user_id,
            "home_currency": row["home_currency"],
            "current_available_balance": parse_decimal(
                row["current_available_balance"]
            ),
            "minimum_balance_to_keep": parse_decimal(
                row["minimum_balance_to_keep"]
            ),
            "financial_priorities": split_pipe_list(
                row["financial_priorities"]
            ),
            "expense_categories_to_protect": split_pipe_list(
                row["expense_categories_to_protect"]
            ),
            "expense_categories_user_is_willing_to_reduce": split_pipe_list(
                row["expense_categories_user_is_willing_to_reduce"]
            ),
            "expense_categories_user_is_willing_to_stop": split_pipe_list(
                row["expense_categories_user_is_willing_to_stop"]
            ),
            "payment_methods_user_will_consider": split_pipe_list(
                row["payment_methods_user_will_consider"]
            ),
            "max_installment_months": (
                int(row["max_installment_months"])
                if row["max_installment_months"].strip()
                else None
            ),
        }

    return profiles


def normalize_requests(
    rows: list[dict[str, str]],
) -> list[dict]:
    """Normalize purchase/request records."""

    normalized = []

    for row in rows:
        normalized.append(
            {
                "request_id": row["request_id"],
                "user_id": row["user_id"],
                "request_date": parse_date(row["request_date"]),
                "request_type": row["request_type"],
                "requested_amount": parse_decimal(
                    row["requested_amount"]
                ),
                "desired_completion_date": parse_date(
                    row["desired_completion_date"]
                ),
                "allows_partial_payment": (
                    row["allows_partial_payment"].strip().lower() == "true"
                ),
                "request_text": row["request_text"],
            }
        )

    return normalized


def normalize_events(
    rows: list[dict[str, str]],
) -> list[dict]:
    """Normalize financial event records."""

    normalized = []

    for row in rows:
        event = {
            "event_id": row["event_id"],
            "user_id": row["user_id"],
            "event_type": row["event_type"],
            "amount": parse_decimal(row["amount"]),
            "category": row["category"],
            "currency": row["currency"],
            "description": row["description"],
            "direction": row["direction"],
            "event_date": parse_date(row["event_date"]),
            "settlement_date": parse_date(
                row["settlement_date"]
            ),
            "status": row["status"],
            "flexibility": row["flexibility"],
            "linked_event_id": row["linked_event_id"].strip(),
            "minimum_allowed_amount": parse_decimal(
                row["minimum_allowed_amount"]
            ),
        }

        # Resolve blank amounts from the supplied images.
        resolved_amount, resolved_currency = resolve_event_amount(
            event
        )

        event["resolved_amount"] = resolved_amount
        event["resolved_currency"] = resolved_currency

        normalized.append(event)

    return normalized
def event_home_currency_amount(
    event: dict,
    home_currency: str,
    fx_index: dict[tuple[date, str, str], Decimal],
) -> Decimal:
    """
    Return an event's resolved amount in the user's home currency.
    """

    amount = event["resolved_amount"]
    currency = event["resolved_currency"]

    if amount is None:
        raise ValueError(
            f"Event {event['event_id']} has no resolved amount."
        )

    event_date = event["event_date"]

    if event_date is None:
        raise ValueError(
            f"Event {event['event_id']} has no event date."
        )

    return convert_to_home_currency(
        amount=amount,
        from_currency=currency,
        home_currency=home_currency,
        rate_date=event_date,
        fx_index=fx_index,
    )
# ============================================================
# EVENT AMOUNT RESOLUTION
# ============================================================

def resolve_event_amount(event: dict) -> tuple[Decimal | None, str]:
    """
    Resolve the usable amount and currency for a normalized event.

    Normally the amount comes directly from financial_events.csv.

    If the CSV amount is blank, the challenge requires us to use
    the corresponding supplied image. The recovered image values
    are stored in IMAGE_RECOVERED_AMOUNTS.
    """

    amount = event["amount"]
    currency = event["currency"]

    # Normal CSV amount.
    if amount is not None:
        return amount, currency

    # Blank amount: recover from the supplied document.
    event_id = event["event_id"]

    recovered = IMAGE_RECOVERED_AMOUNTS.get(event_id)

    if recovered is None:
        raise ValueError(
            f"Event {event_id} has a blank amount but no "
            f"recovered image amount is available."
        )

    recovered_amount, recovered_currency = recovered

    return recovered_amount, recovered_currency

def normalize_payment_options(
    rows: list[dict[str, str]],
) -> list[dict]:
    """Normalize payment/financing options."""

    normalized = []

    for row in rows:
        normalized.append(
            {
                "payment_option_id": row["payment_option_id"],
                "request_id": row["request_id"],
                "payment_method": row["payment_method"],
                "payment_amount": parse_decimal(
                    row["payment_amount"]
                ),
                "number_of_payments": int(
                    row["number_of_payments"]
                ),
                "payment_frequency_days": (
                    int(row["payment_frequency_days"])
                    if row["payment_frequency_days"].strip()
                    else None
                ),
                "first_payment_date": parse_date(
                    row["first_payment_date"]
                ),
                "financing_fee": parse_decimal(
                    row["financing_fee"]
                ),
                "total_payable_amount": parse_decimal(
                    row["total_payable_amount"]
                ),
            }
        )

    return normalized


def normalize_messages(
    rows: list[dict[str, str]],
) -> list[dict]:
    """Normalize message records."""

    normalized = []

    for row in rows:
        normalized.append(
            {
                "message_id": row["message_id"],
                "related_event_id": row["related_event_id"].strip(),
                "request_id": row["request_id"].strip(),
                "user_id": row["user_id"],
                "sent_at": row["sent_at"],
                "source_type": row["source_type"],
                "message_text": row["message_text"],
            }
        )

    return normalized


def normalize_images(
    rows: list[dict[str, str]],
) -> list[dict]:
    """Normalize image metadata."""

    normalized = []

    for row in rows:
        normalized.append(
            {
                "image_id": row["image_id"],
                "related_event_id": row["related_event_id"],
                "request_id": row["request_id"],
                "user_id": row["user_id"],
            }
        )

    return normalized


def normalize_exchange_rates(
    rows: list[dict[str, str]],
) -> list[dict]:
    """Normalize dated FX rates."""

    normalized = []

    for row in rows:
        normalized.append(
            {
                "rate_date": parse_date(row["rate_date"]),
                "from_currency": row["from_currency"],
                "to_currency": row["to_currency"],
                "rate": parse_decimal(row["rate"]),
            }
        )

    return normalized

# ============================================================
# FX CONVERSION
# ============================================================

def build_fx_index(
    exchange_rates: list[dict],
) -> dict[tuple[date, str, str], Decimal]:
    """
    Build a deterministic lookup for dated FX rates.

    Key:
        (rate_date, from_currency, to_currency)

    Value:
        exchange rate
    """

    fx_index = {}

    for row in exchange_rates:
        key = (
            row["rate_date"],
            row["from_currency"],
            row["to_currency"],
        )

        if row["rate"] is None:
            raise ValueError(
                f"Missing FX rate for {key}"
            )

        if key in fx_index:
            raise ValueError(
                f"Duplicate FX rate for {key}"
            )

        fx_index[key] = row["rate"]

    return fx_index

def convert_to_home_currency(
    amount: Decimal,
    from_currency: str,
    home_currency: str,
    rate_date: date,
    fx_index: dict[tuple[date, str, str], Decimal],
) -> Decimal:
    """
    Convert an amount into the user's home currency using
    the exchange rate for the exact supplied date.
    """

    if amount is None:
        raise ValueError(
            "Cannot convert a missing amount."
        )

    if from_currency == home_currency:
        return amount

    key = (
        rate_date,
        from_currency,
        home_currency,
    )

    rate = fx_index.get(key)

    if rate is None:
        raise ValueError(
            "Missing dated FX rate: "
            f"{rate_date} {from_currency}->{home_currency}"
        )

    return amount * rate

def build_indexes(
    profiles: dict[str, dict],
    requests: list[dict],
    events: list[dict],
    payment_options: list[dict],
    messages: list[dict],
    images: list[dict],
) -> dict:
    """Build indexes used by the financial decision engine."""

    requests_by_id = {
        request["request_id"]: request
        for request in requests
    }

    events_by_id = {
        event["event_id"]: event
        for event in events
    }

    events_by_user = {}

    for event in events:
        events_by_user.setdefault(
            event["user_id"],
            [],
        ).append(event)

    options_by_request = {}

    for option in payment_options:
        options_by_request.setdefault(
            option["request_id"],
            [],
        ).append(option)

    messages_by_event = {}

    for message in messages:
        related_event_id = message["related_event_id"]

        if related_event_id:
            messages_by_event.setdefault(
                related_event_id,
                [],
            ).append(message)

    messages_by_user = {}

    for message in messages:
        messages_by_user.setdefault(
            message["user_id"],
            [],
        ).append(message)

    for user_messages in messages_by_user.values():
        user_messages.sort(
            key=lambda message: (
                message["sent_at"],
                message["message_id"],
            )
        )
    
    images_by_event = {}

    for image in images:
        related_event_id = image["related_event_id"]

        if related_event_id:
            images_by_event.setdefault(
                related_event_id,
                [],
            ).append(image)

    return {
        "profiles": profiles,
        "requests_by_id": requests_by_id,
        "events_by_id": events_by_id,
        "events_by_user": events_by_user,
        "options_by_request": options_by_request,
        "messages_by_event": messages_by_event,
        "messages_by_user": messages_by_user,
        "images_by_event": images_by_event,
    }

# ============================================================
# EVENT LIFECYCLE / CONFLICT RESOLUTION
# ============================================================

def resolve_event_lifecycle(
    events: list[dict],
    messages_by_event: dict[str, list[dict]],
) -> list[dict]:
    """
    Resolve obvious event lifecycle conflicts before forecasting.

    The challenge can contain:
      - duplicate records
      - cancellations
      - amendments
      - replacement records
      - settled records superseding estimates

    This function deliberately stays conservative:
    it never invents a replacement event or amount.
    """

    events_by_id = {
        event["event_id"]: event
        for event in events
    }

    resolved = []

    for event in events:
        # Explicitly ignored statuses are handled by the forecast
        # layer, but we retain the records here because messages
        # may refer to them.
        resolved.append(event)

    return resolved

def print_fx_diagnostics(
    events: list[dict],
    profiles: dict[str, dict],
    fx_index: dict[tuple[date, str, str], Decimal],
) -> None:
    """Validate that all event currencies can be converted."""

    converted_count = 0
    already_home_currency = 0
    required_pairs = set()

    for event in events:
        profile = profiles.get(event["user_id"])

        if profile is None:
            raise ValueError(
                f"No profile found for user {event['user_id']}"
            )

        home_currency = profile["home_currency"]
        event_currency = event["resolved_currency"]
        event_date = event["event_date"]

        if event_currency == home_currency:
            already_home_currency += 1
            converted_count += 1
            continue

        key = (
            event_date,
            event_currency,
            home_currency,
        )

        required_pairs.add(key)

        # This deliberately validates availability.
        if key not in fx_index:
            raise ValueError(
                "Missing FX rate required by event "
                f"{event['event_id']}: "
                f"{event_date} "
                f"{event_currency}->{home_currency}"
            )

        converted_count += 1

    print("\nFX diagnostics:")
    print(f"  Events checked: {len(events)}")
    print(f"  Events already in home currency: {already_home_currency}")
    print(f"  Events successfully convertible: {converted_count}")
    print(f"  Distinct dated FX lookups required: {len(required_pairs)}")

# ============================================================
# EVENT DIAGNOSTICS
# ============================================================

def print_event_diagnostics(events: list[dict]) -> None:
    """Print event-state statistics for validation."""

    status_counts = {}

    for event in events:
        status = event["status"]
        status_counts[status] = status_counts.get(status, 0) + 1

    print("\nEvent status counts:")
    for status in sorted(status_counts):
        print(f"  {status}: {status_counts[status]}")

    type_counts = {}

    for event in events:
        event_type = event["event_type"]
        type_counts[event_type] = type_counts.get(event_type, 0) + 1

    print("\nEvent type counts:")
    for event_type in sorted(type_counts):
        print(f"  {event_type}: {type_counts[event_type]}")

    flexibility_counts = {}

    for event in events:
        flexibility = event["flexibility"]
        flexibility_counts[flexibility] = (
            flexibility_counts.get(flexibility, 0) + 1
        )

    print("\nFlexibility counts:")
    for flexibility in sorted(flexibility_counts):
        print(f"  {flexibility}: {flexibility_counts[flexibility]}")

    blank_amount_events = [
        event
        for event in events
        if event["amount"] is None
    ]

    print(
        f"\nEvents with blank amount: "
        f"{len(blank_amount_events)}"
    )

    if blank_amount_events:
        print("Blank-amount event IDs:")

        for event in blank_amount_events:
            print(
                f"  {event['event_id']} | "
                f"user={event['user_id']} | "
                f"type={event['event_type']} | "
                f"status={event['status']}"
            )

    unresolved_events = [
        event
        for event in events
        if event["resolved_amount"] is None
    ]

    print(
        f"\nEvents with unresolved amounts: "
        f"{len(unresolved_events)}"
    )

    if unresolved_events:
        for event in unresolved_events:
            print(
                f"  UNRESOLVED: {event['event_id']}"
            )

# ============================================================
# RECURRING EVENT DETECTION
# ============================================================

def days_between(
    earlier: date | None,
    later: date | None,
) -> int | None:
    """Return the number of days between two dates."""

    if earlier is None or later is None:
        return None

    return (later - earlier).days


def is_recurring_candidate(event: dict) -> bool:
    """
    Return True when an event type/category can reasonably
    participate in recurring-pattern detection.
    """

    return event["event_type"] in {
        "income",
        "expense",
        "subscription",
    }


def detect_recurring_event_groups(
    events: list[dict],
) -> list[list[dict]]:
    """
    Detect groups of historical events that appear recurring.

    This is intentionally conservative. We require:
      - same user
      - same event type
      - same category
      - same direction
      - similar amount
      - approximately monthly cadence

    One-time purchases and transfers are not treated as recurring.
    """

    historical = [
        event
        for event in events
        if (
            is_financially_active_event(event)
            and is_recurring_candidate(event)
            and event["event_date"] is not None
        )
    ]

    groups: dict[tuple, list[dict]] = {}

    for event in historical:
        key = (
            event["user_id"],
            event["event_type"],
            event["category"],
            event["direction"],
        )

        groups.setdefault(key, []).append(event)

    recurring_groups = []

    for group in groups.values():
        group.sort(
            key=lambda event: event["event_date"]
        )

        if len(group) < 2:
            continue

        intervals = []

        for previous, current in zip(group, group[1:]):
            delta = days_between(
                previous["event_date"],
                current["event_date"],
            )

            if delta is not None:
                intervals.append(delta)

        if not intervals:
            continue

        # Monthly patterns commonly fall around 28-31 days.
        monthly_intervals = [
            interval
            for interval in intervals
            if 25 <= interval <= 35
        ]

        if len(monthly_intervals) >= 1:
            recurring_groups.append(group)

    return recurring_groups

# ============================================================
# MESSAGE-BASED FUTURE PROJECTION OVERRIDES
# ============================================================

import re


def parse_message_datetime(value: str) -> datetime:
    """Parse the ISO timestamp used by messages.csv."""

    return datetime.strptime(
        value,
        "%Y-%m-%dT%H:%M:%SZ",
    )


def get_messages_effective_for_request(
    request: dict,
    messages_by_user: dict[str, list[dict]],
) -> list[dict]:
    """
    Return messages that were available by the time of the request.

    A later message must never alter an earlier request's forecast.
    """

    request_date = request["request_date"]

    if request_date is None:
        return []

    effective = []

    for message in messages_by_user.get(
        request["user_id"],
        [],
    ):
        sent_at = message["sent_at"]

        if not sent_at:
            continue

        sent_date = parse_message_datetime(sent_at).date()

        if sent_date <= request_date:
            effective.append(message)

    effective.sort(
        key=lambda message: (
            message["sent_at"],
            message["message_id"],
        )
    )

    return effective


def extract_confirmed_salary_amount(
    message_text: str,
) -> Decimal | None:
    """
    Extract a confirmed base/monthly salary amount from a
    payroll message.

    This intentionally handles only the message patterns
    present in the supplied challenge data.
    """

    patterns = [
        r"confirmed\s+base\s+salary\s+(?:is\s+)?([A-Z]{3})\s*([0-9]+(?:\.[0-9]+)?)",
        r"remaining\s+confirmed\s+monthly\s+salary\s+is\s+([A-Z]{3})\s*([0-9]+(?:\.[0-9]+)?)",
    ]

    for pattern in patterns:
        match = re.search(
            pattern,
            message_text,
            flags=re.IGNORECASE,
        )

        if match:
            return Decimal(match.group(2))

    return None

def extract_confirmed_salary_currency(
    message_text: str,
) -> str | None:
    """
    Extract the currency associated with a confirmed salary
    message.
    """

    patterns = [
        r"confirmed\s+base\s+salary\s+(?:is\s+)?([A-Z]{3})",
        r"remaining\s+confirmed\s+monthly\s+salary\s+is\s+([A-Z]{3})",
    ]

    for pattern in patterns:
        match = re.search(
            pattern,
            message_text,
            flags=re.IGNORECASE,
        )

        if match:
            return match.group(1).upper()

    return None

def extract_confirmed_payroll_date(
    message_text: str,
) -> date | None:
    patterns = [
        r"confirmed\s+salary\s+is\s+now\s+expected\s+on\s+(\d{4}-\d{2}-\d{2})",
        r"payroll\s+date\s+(?:is\s+now\s+)?(?:expected\s+on\s+)?(\d{4}-\d{2}-\d{2})",
    ]

    for pattern in patterns:
        match = re.search(
            pattern,
            message_text,
            flags=re.IGNORECASE,
        )
        if match:
            return date.fromisoformat(match.group(1))

    return None

def message_projection_overrides(
    request: dict,
    messages_by_user: dict[str, list[dict]],
) -> dict:
    """
    Interpret supported employer/payroll messages that affect
    future recurring-income projections.

    The returned structure contains only future-projection
    instructions. Historical events are never modified.
    """

    overrides = {
        "salary_amount": None,
        "salary_currency": None,
        "replace_salary_streams": False,
        "exclude_commission": False,
        "payroll_date": None,
    }

    messages = get_messages_effective_for_request(
        request=request,
        messages_by_user=messages_by_user,
    )

    for message in messages:

        if message["source_type"] != "employer":
            continue

        text = message["message_text"]

        lower_text = text.lower()

        # ----------------------------------------------------
        # Confirmed base salary / remaining salary.
        # ----------------------------------------------------

        salary_amount = extract_confirmed_salary_amount(
            text
        )

        salary_currency = extract_confirmed_salary_currency(
            text
        )

        if salary_amount is not None:
            overrides["salary_amount"] = salary_amount
            overrides["salary_currency"] = salary_currency

        # ----------------------------------------------------
        # Household employment ended.
        # ----------------------------------------------------

        if (
            "household employment record has ended"
            in lower_text
            and "remaining confirmed monthly salary"
            in lower_text
        ):
            overrides["replace_salary_streams"] = True

        # ----------------------------------------------------
        # Commission pending / unearned.
        # ----------------------------------------------------

        if (
            "commission" in lower_text
            and (
                "pending approval" in lower_text
                or "pending" in lower_text
            )
            and (
                "stay out" in lower_text
                or "out of the payout" in lower_text
                or "until the commission is marked as earned"
                in lower_text
            )
        ):
            overrides["exclude_commission"] = True

        # ----------------------------------------------------
        # Payroll-date correction.
        # ----------------------------------------------------

        payroll_match = re.search(
            r"confirmed\s+salary\s+is\s+now\s+expected\s+on\s+"
            r"(\d{4}-\d{2}-\d{2})",
            text,
            flags=re.IGNORECASE,
        )

        if payroll_match:
            overrides["payroll_date"] = parse_date(
                payroll_match.group(1)
            )

    return overrides

# ============================================================
# PRODUCTION RECURRING PATTERN MODEL
# ============================================================

def recurring_group_key(event: dict) -> tuple:
    """
    Identify a recurring financial stream.

    Salary streams are separated by their description because
    base salary and commission income are financially different
    streams. Other recurring events continue to use the broader
    financial identity.
    """

    if (
        event["event_type"] == "income"
        and event["category"] == "salary"
        and event["direction"] == "credit"
    ):
        return (
            event["user_id"],
            event["event_type"],
            event["category"],
            event["direction"],
            event["description"].strip().lower(),
        )

    return (
        event["user_id"],
        event["event_type"],
        event["category"],
        event["direction"],
    )


def is_monthly_cadence(
    events: list[dict],
) -> bool:
    """
    Determine whether recent events follow a monthly cadence.

    We use the most recent intervals because old history may
    contain one-off gaps or lifecycle changes.
    """

    if len(events) < 3:
        return False

    ordered = sorted(
        events,
        key=lambda event: event["event_date"],
    )

    recent = ordered[-5:]

    intervals = []

    for previous, current in zip(
        recent,
        recent[1:],
    ):
        delta = days_between(
            previous["event_date"],
            current["event_date"],
        )

        if delta is not None:
            intervals.append(delta)

    if len(intervals) < 2:
        return False

    monthly_count = sum(
        25 <= interval <= 35
        for interval in intervals
    )

    return monthly_count >= max(
        2,
        len(intervals) - 1,
    )


def build_recurring_streams(
    events: list[dict],
) -> list[dict]:
    """
    Build production-quality recurring financial streams.

    Each stream represents one recurring income/expense/
    subscription pattern for one user.
    """

    candidates = {}

    for event in events:
        if not is_financially_active_event(event):
            continue

        if not is_recurring_candidate(event):
            continue

        if event["event_date"] is None:
            continue

        key = recurring_group_key(event)

        candidates.setdefault(key, []).append(event)

    streams = []

    for key, group in candidates.items():

        group.sort(
            key=lambda event: event["event_date"]
        )

        # Require enough historical evidence.
        if len(group) < 3:
            continue

        if not is_monthly_cadence(group):
            continue

        recent = group[-5:]

        intervals = []

        for previous, current in zip(
            recent,
            recent[1:],
        ):
            delta = days_between(
                previous["event_date"],
                current["event_date"],
            )

            if delta is not None:
                intervals.append(delta)

        if not intervals:
            continue

        # Median cadence is more robust than simply using
        # the last interval.
        intervals_sorted = sorted(intervals)

        middle = len(intervals_sorted) // 2

        if len(intervals_sorted) % 2 == 1:
            cadence_days = intervals_sorted[middle]
        else:
            cadence_days = (
                intervals_sorted[middle - 1]
                + intervals_sorted[middle]
            ) // 2

        latest = group[-1]
        observed_days = [
        event["event_date"].day
        for event in recent
        if event["event_date"] is not None
        ]

        if observed_days:
            anchor_day = Counter(observed_days).most_common(1)[0][0]
        else:
            anchor_day = latest["event_date"].day

        streams.append(
            {
                "key": key,
                "user_id": latest["user_id"],
                "event_type": latest["event_type"],
                "category": latest["category"],
                "direction": latest["direction"],
                "events": group,
                "latest_event": latest,
                "latest_date": latest["event_date"],
                "latest_amount": latest["resolved_amount"],
                "latest_currency": latest["resolved_currency"],
                "latest_home_amount": latest["home_amount"],
                "latest_flexibility": latest["flexibility"],
                "minimum_allowed_amount": (
                    latest["minimum_allowed_amount"]
                ),
                "cadence_days": cadence_days,
                "anchor_day": anchor_day,
            }
        )

    return streams

def add_months_preserving_day(
    source_date: date,
    months: int,
) -> date:
    """
    Advance a date by calendar months while preserving the
    day-of-month where possible.

    If the target month has fewer days, clamp to the final
    valid day of that month.
    """

    month_index = (
        source_date.year * 12
        + (source_date.month - 1)
        + months
    )

    target_year = month_index // 12
    target_month = month_index % 12 + 1

    # Find the final day of the target month.
    if target_month == 12:
        next_month = date(
            target_year + 1,
            1,
            1,
        )
    else:
        next_month = date(
            target_year,
            target_month + 1,
            1,
        )

    last_day = (
        next_month
        - timedelta(days=1)
    ).day

    target_day = min(
        source_date.day,
        last_day,
    )

    return date(
        target_year,
        target_month,
        target_day,
    )

def project_recurring_events(
    request: dict,
    streams: list[dict],
    existing_events: list[dict],
    messages_by_user: dict[str, list[dict]],
    profile: dict,
    fx_index: dict[tuple[date, str, str], Decimal],
) -> list[dict]:
    """
    Project future occurrences of recurring streams into the
    request's 90-day forecast window.

    Existing active events are never duplicated.
    """

    request_date = request["request_date"]

    if request_date is None:
        raise ValueError(
            f"Request {request['request_id']} has no request date."
        )

    forecast_end = request_date + timedelta(days=90)
    user_id = request["user_id"]
    overrides = message_projection_overrides(
    request=request,
    messages_by_user=messages_by_user,
    )

    # --------------------------------------------------------
    # Existing active event dates.
    # --------------------------------------------------------

    existing_keys = set()

    for event in existing_events:
        if event["user_id"] != user_id:
            continue

        if not is_financially_active_event(event):
            continue

        forecast_date = event_forecast_date(event)

        if forecast_date is None:
            continue

        existing_keys.add(
            (
                event["event_type"],
                event["category"],
                event["direction"],
                forecast_date,
            )
        )

    projected = []

    # --------------------------------------------------------
    # Project each recurring stream.
    # --------------------------------------------------------

    for stream in streams:

        if stream["user_id"] != user_id:
            continue

        # ----------------------------------------------------
        # Employer-message salary overrides.
        # ----------------------------------------------------

        is_salary_stream = (
            stream["event_type"] == "income"
            and stream["category"] == "salary"
            and stream["direction"] == "credit"
        )

        if is_salary_stream:

            description = (
                stream["latest_event"]["description"]
                .strip()
                .lower()
            )

            # ------------------------------------------------
            # Household employment ended.
            #
            # The employer message explicitly says that one
            # household employment record ended and gives the
            # remaining confirmed monthly salary.
            #
            # Keep only the primary household salary stream as
            # the carrier for the replacement salary.
            # ------------------------------------------------

            if overrides["replace_salary_streams"]:
                if description != "primary household salary":
                    continue

            # ------------------------------------------------
            # Unearned commission.
            #
            # Pending/open commissions must not be projected.
            # ------------------------------------------------

            if (
                overrides["exclude_commission"]
                and "commission" in description
            ):
                continue
        # Find the most recent actual active event belonging
        # to this recurring stream.
        stream_events = [
            event
            for event in existing_events
            if (
                event["user_id"] == stream["user_id"]
                and event["event_type"] == stream["event_type"]
                and event["category"] == stream["category"]
                and event["direction"] == stream["direction"]
                and is_financially_active_event(event)
                and event_forecast_date(event) is not None
            )
        ]

        if stream_events:
            latest_actual = max( stream_events, key=lambda event: event_forecast_date(event),)

            latest_date = event_forecast_date(latest_actual)
            latest_amount = latest_actual["resolved_amount"]
            latest_currency = latest_actual["resolved_currency"]

        else:
            latest_date = stream["latest_date"]
            latest_amount = stream["latest_amount"]
            latest_currency = stream["latest_currency"]

        if latest_date is None:
            continue

        # ----------------------------------------------------
        # Apply employer-confirmed salary override.
        #
        # This changes ONLY future projected salary events.
        # Historical events remain untouched.
        # ----------------------------------------------------

        if (
            is_salary_stream
            and overrides["salary_amount"] is not None
        ):
            latest_amount = overrides["salary_amount"]

            if overrides["salary_currency"] is None:
                raise ValueError(
                    "Confirmed salary amount was found but "
                    "salary currency could not be determined "
                    f"for request {request['request_id']}."
                )

            latest_currency = overrides["salary_currency"]

        # ----------------------------------------------------
        # Generate future calendar-month occurrences.
        # ----------------------------------------------------

        next_month_offset = 1

        while True:
            candidate = add_months_preserving_day(
                latest_date,
                next_month_offset,
            )

            # Respect the recurring stream's inferred
            # calendar day.
            try:
                next_date = date(
                    candidate.year,
                    candidate.month,
                    stream["anchor_day"],
                )

            except ValueError:
                # The target month is shorter than the anchor day.
                # Clamp to the final valid day of that month.
                if candidate.month == 12:
                    following_month = date(
                        candidate.year + 1,
                        1,
                        1,
                    )
                else:
                    following_month = date(
                        candidate.year,
                        candidate.month + 1,
                        1,
                    )

                last_day = (
                    following_month - timedelta(days=1)
                ).day

                next_date = date(
                    candidate.year,
                    candidate.month,
                    last_day,
                )

            # Stop once we leave the 90-day forecast window.
            if next_date > forecast_end:
                break

            next_month_offset += 1

            # Do not project an occurrence that is on or before
            # the request date.
            if next_date <= request_date:
                continue

            key = (
                stream["event_type"],
                stream["category"],
                stream["direction"],
                next_date,
            )

            # Never duplicate an already represented event.
            if key in existing_keys:
                continue

                       # ------------------------------------------------
            # Convert the projected occurrence using the FX
            # rate for the projected event date.
            #
            # Do NOT reuse the historical event's home_amount:
            # the challenge supplies dated FX rates.
            # ------------------------------------------------

            projected_home_amount = convert_to_home_currency(
                amount=latest_amount,
                from_currency=latest_currency,
                home_currency=profile["home_currency"],
                rate_date=next_date,
                fx_index=fx_index,
            )

            projected.append(
                {
                    "event_id": (
                        f"projected_"
                        f"{stream['user_id']}_"
                        f"{stream['event_type']}_"
                        f"{stream['category']}_"
                        f"{next_date.isoformat()}"
                    ),
                    "user_id": stream["user_id"],
                    "event_type": stream["event_type"],
                    "category": stream["category"],
                    "currency": latest_currency,
                    "resolved_amount": latest_amount,
                    "resolved_currency": latest_currency,
                    "home_amount": projected_home_amount,
                    "direction": stream["direction"],
                    "event_date": next_date,
                    "settlement_date": next_date,
                    "status": "projected",
                    "flexibility": stream["latest_flexibility"],
                    "linked_event_id": "",
                    "minimum_allowed_amount": (
                        stream["minimum_allowed_amount"]
                    ),
                    "projected": True,
                }
            )

    return projected

def get_forecast_events(
    request: dict,
    events_by_user: dict[str, list[dict]],
    recurring_streams: list[dict],
    messages_by_user: dict[str, list[dict]],
    profile: dict,
    fx_index: dict[tuple[date, str, str], Decimal],
) -> list[dict]:
    """
    Return actual active future events plus carefully projected
    recurring events for the request's 90-day window.
    """

    actual_events = events_by_user.get(
        request["user_id"],
        [],
    )

    projected_events = project_recurring_events(
        request=request,
        streams=recurring_streams,
        existing_events=actual_events,
        messages_by_user=messages_by_user,
        profile=profile,
        fx_index=fx_index,
    )

    combined = []

    for event in actual_events:

        if not is_financially_active_event(event):
            continue

        forecast_date = event_forecast_date(event)

        if forecast_date is None:
            continue

        if (
            request["request_date"]
            < forecast_date
            <= request["request_date"] + timedelta(days=90)
        ):
            combined.append(event)

    combined.extend(projected_events)

    combined.sort(
        key=lambda event: (
            event_forecast_date(event),
            event["event_id"],
        )
    )

    return combined

def print_projection_diagnostics(
    requests: list[dict],
    events_by_user: dict[str, list[dict]],
    recurring_streams: list[dict],
    messages_by_user: dict[str, list[dict]],
    profiles: dict[str, dict],
    fx_index: dict[tuple[date, str, str], Decimal],
) -> None:
    """
    Print projected recurring events for a small number of
    requests.

    Diagnostic only.
    """

    print("\n" + "=" * 80)
    print("RECURRING PROJECTION DIAGNOSTICS")
    print("=" * 80)

    shown = 0

    for request in requests:

        projected = project_recurring_events(
            request=request,
            streams=recurring_streams,
            existing_events=events_by_user.get(
                request["user_id"],
                [],
            ),
            messages_by_user=messages_by_user,
            profile=profiles[request["user_id"]],
            fx_index=fx_index,
        )

        if not projected:
            continue

        print(
            f"\nRequest {request['request_id']} | "
            f"user={request['user_id']} | "
            f"date={request['request_date']}"
        )

        for event in projected:
            print(
                f"  PROJECTED | "
                f"{event['event_date']} | "
                f"{event['event_type']} | "
                f"{event['category']} | "
                f"{event['resolved_amount']} "
                f"{event['resolved_currency']} | "
                f"{event['direction']} | "
                f"flex={event['flexibility']}"
            )

        shown += 1

        if shown >= 10:
            break

def print_recurring_diagnostics(
    recurring_groups: list[list[dict]],
) -> None:
    """
    Print useful statistics about detected recurring patterns.

    This is diagnostic only. It does not modify the financial
    decision logic.
    """

    if not recurring_groups:
        print("\nNo recurring candidate groups detected.")
        return

    print("\n" + "=" * 80)
    print("RECURRING PATTERN DIAGNOSTICS")
    print("=" * 80)

    print(
        f"Recurring candidate groups: "
        f"{len(recurring_groups)}"
    )

    # --------------------------------------------------------
    # Group-size distribution
    # --------------------------------------------------------

    size_counts: dict[int, int] = {}

    for group in recurring_groups:
        size = len(group)
        size_counts[size] = size_counts.get(size, 0) + 1

    print("\nGroup size distribution:")

    for size in sorted(size_counts):
        print(
            f"  {size} events: "
            f"{size_counts[size]} groups"
        )

    # --------------------------------------------------------
    # Event type distribution
    # --------------------------------------------------------

    type_counts: dict[str, int] = {}

    for group in recurring_groups:
        event_type = group[0]["event_type"]

        type_counts[event_type] = (
            type_counts.get(event_type, 0) + 1
        )

    print("\nRecurring groups by event type:")

    for event_type in sorted(type_counts):
        print(
            f"  {event_type}: "
            f"{type_counts[event_type]}"
        )

    # --------------------------------------------------------
    # Flexibility distribution
    # --------------------------------------------------------

    flexibility_counts: dict[str, int] = {}

    for group in recurring_groups:
        # Use the most recent event because this is the
        # event closest to a future forecast.
        event = group[-1]

        flexibility = event["flexibility"]

        flexibility_counts[flexibility] = (
            flexibility_counts.get(flexibility, 0) + 1
        )

    print("\nRecurring groups by latest-event flexibility:")

    for flexibility in sorted(flexibility_counts):
        print(
            f"  {flexibility}: "
            f"{flexibility_counts[flexibility]}"
        )

    # --------------------------------------------------------
    # Show longest recurring groups
    # --------------------------------------------------------

    longest_groups = sorted(
        recurring_groups,
        key=lambda group: len(group),
        reverse=True,
    )

    print("\nLongest recurring groups:")

    for group in longest_groups[:10]:
        first = group[0]
        last = group[-1]

        print(
            f"  user={first['user_id']} | "
            f"type={first['event_type']} | "
            f"category={first['category']} | "
            f"direction={first['direction']} | "
            f"events={len(group)} | "
            f"first={first['event_date']} | "
            f"last={last['event_date']} | "
            f"last_amount={last['resolved_amount']} "
            f"{last['resolved_currency']} | "
            f"flex={last['flexibility']}"
        )


# ============================================================
# EVENT STATE RULES
# ============================================================

IGNORED_EVENT_STATUSES = {
    "cancelled",
    "failed",
    "pending",
    "unrealized",
}


def is_financially_active_event(event: dict) -> bool:
    """
    Return True when an event should participate in the
    financial forecast.
    """

    return event["status"] not in IGNORED_EVENT_STATUSES

def event_forecast_date(event: dict) -> date | None:
    """
    Determine the date on which an active event affects the
    forecast balance.
    """

    if not is_financially_active_event(event):
        return None

    # Confirmed income is available on its settlement date.
    if (
        event["event_type"] == "income"
        and event["settlement_date"] is not None
    ):
        return event["settlement_date"]

    return event["event_date"]

def event_signed_amount(event: dict) -> Decimal:
    """
    Return the event's home-currency amount with the correct
    balance direction.
    """

    amount = event["home_amount"]

    if amount is None:
        raise ValueError(
            f"Event {event['event_id']} has no home amount."
        )

    direction = event["direction"]

    if direction == "credit":
        return amount

    if direction == "debit":
        return -amount

    # Investment valuation is non-cash and must not affect
    # the cash forecast.
    if direction == "non_cash":
        return Decimal("0")

    raise ValueError(
        f"Unknown event direction {direction!r} "
        f"for {event['event_id']}"
    )

def get_active_events_for_request(
    request: dict,
    events_by_user: dict[str, list[dict]],
) -> list[dict]:
    """
    Return active events relevant to this request's 90-day
    forecast window.
    """

    user_id = request["user_id"]
    request_date = request["request_date"]

    if request_date is None:
        raise ValueError(
            f"Request {request['request_id']} has no request date."
        )

    forecast_end = request_date + timedelta(days=90)

    relevant = []

    for event in events_by_user.get(user_id, []):
        if not is_financially_active_event(event):
            continue

        forecast_date = event_forecast_date(event)

        if forecast_date is None:
            continue

        if request_date < forecast_date <= forecast_end:
            relevant.append(event)

    relevant.sort(
        key=lambda event: (
            event_forecast_date(event),
            event["event_id"],
        )
    )

    return relevant

def build_daily_forecast(
    request: dict,
    profile: dict,
    events_by_user: dict[str, list[dict]],
    recurring_streams: list[dict],
    messages_by_user: dict[str, list[dict]],
    fx_index: dict[tuple[date, str, str], Decimal],
) -> dict[date, Decimal]:
    """
    Build the user's projected end-of-day balance for each day
    in the 90-day forecast window.
    """

    request_date = request["request_date"]

    if request_date is None:
        raise ValueError(
            f"Request {request['request_id']} has no request date."
        )

    starting_balance = profile["current_available_balance"]

    if starting_balance is None:
        raise ValueError(
            f"User {profile['user_id']} has no available balance."
        )

    forecast_end = request_date + timedelta(days=90)

    daily_changes: dict[date, Decimal] = {}

    for event in get_forecast_events(
        request=request,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        profile=profile,
        fx_index=fx_index,
    ):

        forecast_date = event_forecast_date(event)

        if forecast_date is None:
            continue

        daily_changes[forecast_date] = (
            daily_changes.get(
                forecast_date,
                Decimal("0"),
            )
            + event_signed_amount(event)
        )

    balances: dict[date, Decimal] = {}

    balance = starting_balance

    current_day = request_date

    while current_day <= forecast_end:
        if current_day != request_date:
            balance += daily_changes.get(
                current_day,
                Decimal("0"),
            )

        balances[current_day] = balance

        current_day += timedelta(days=1)

    return balances

def is_safe_after_payment(
    request: dict,
    profile: dict,
    events_by_user: dict[str, list[dict]],
    recurring_streams: list[dict],
    messages_by_user: dict[str, list[dict]],
    fx_index: dict[tuple[date, str, str], Decimal],
    additional_payment: Decimal,
) -> bool:
    """
    Return True when making an additional payment on the request date
    keeps the user's balance at or above the required minimum
    throughout the 90-day forecast window.
    """

    balances = build_daily_forecast(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
    )

    minimum_balance = profile["minimum_balance_to_keep"]

    if minimum_balance is None:
        raise ValueError(
            f"User {profile['user_id']} has no minimum balance."
        )

    request_date = request["request_date"]

    for forecast_date, balance in balances.items():

        adjusted_balance = balance

        if forecast_date == request_date:
            adjusted_balance -= additional_payment

        if adjusted_balance < minimum_balance:
            return False

    return True


def calculate_amount_safe_to_pay(
    request: dict,
    profile: dict,
    events_by_user: dict[str, list[dict]],
    recurring_streams: list[dict],
    messages_by_user: dict[str, list[dict]],
    fx_index: dict[tuple[date, str, str], Decimal],
) -> Decimal:
    """
    Calculate the maximum amount that can be paid on the request date
    while keeping the user's balance at or above the required minimum
    throughout the 90-day forecast window.

    This uses the same safety engine as all other payment decisions.
    """

    requested_amount = request["requested_amount"]
    request_date = request["request_date"]

    if requested_amount is None:
        raise ValueError(
            f"Request {request['request_id']} has no requested amount."
        )

    if request_date is None:
        raise ValueError(
            f"Request {request['request_id']} has no request date."
        )

    if requested_amount <= Decimal("0"):
        return Decimal("0")

    # If the full requested amount is safe today, return it immediately.
    if is_safe_with_payments(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
        payments=[(request_date, requested_amount)],
    ):
        return requested_amount

    # If even zero additional payment is unsafe, no amount is safely
    # payable today.
    if not is_safe_with_payments(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
        payments=[],
    ):
        return Decimal("0")

    # Binary search for the largest safe payment.
    low = Decimal("0")
    high = requested_amount

    for _ in range(100):
        if high - low <= Decimal("0.01"):
            break

        mid = (low + high) / Decimal("2")

        if is_safe_with_payments(
            request=request,
            profile=profile,
            events_by_user=events_by_user,
            recurring_streams=recurring_streams,
            messages_by_user=messages_by_user,
            fx_index=fx_index,
            payments=[(request_date, mid)],
        ):
            low = mid
        else:
            high = mid

    # Round down to cents.
    safe_amount = low.quantize(Decimal("0.01"))

    # Guard against rounding above the actual safe boundary.
    while safe_amount > Decimal("0") and not is_safe_with_payments(
        request=request,
        profile=profile,
        events_by_user=events_by_user,
        recurring_streams=recurring_streams,
        messages_by_user=messages_by_user,
        fx_index=fx_index,
        payments=[(request_date, safe_amount)],
    ):
        safe_amount -= Decimal("0.01")

    return safe_amount

def print_request_event_diagnostic(
    request: dict,
    indexes: dict,
) -> None:
    """Print the financial history and future events for one request."""

    profile = indexes["profiles"][request["user_id"]]

    request_date = request["request_date"]

    print("\n" + "=" * 80)
    print(f"REQUEST DIAGNOSTIC: {request['request_id']}")
    print("=" * 80)

    print(f"User: {request['user_id']}")
    print(f"Request date: {request_date}")
    print(f"Home currency: {profile['home_currency']}")
    print(
        f"Starting balance: "
        f"{profile['current_available_balance']}"
    )
    print(
        f"Minimum balance: "
        f"{profile['minimum_balance_to_keep']}"
    )

    user_events = indexes["events_by_user"].get(
        request["user_id"],
        [],
    )

    historical = []
    future = []

    forecast_end = request_date + timedelta(days=90)

    for event in user_events:
        if not is_financially_active_event(event):
            continue

        event_date = event_forecast_date(event)

        if event_date is None:
            continue

        if event_date <= request_date:
            historical.append(event)

        elif event_date <= forecast_end:
            future.append(event)

    historical.sort(
        key=lambda e: (
            event_forecast_date(e),
            e["event_id"],
        )
    )

    future.sort(
        key=lambda e: (
            event_forecast_date(e),
            e["event_id"],
        )
    )

    print(f"\nHistorical active events: {len(historical)}")
    print(f"Future active events in 90 days: {len(future)}")

    print("\nFuture events:")

    for event in future:
        print(
            f"  {event_forecast_date(event)} | "
            f"{event['event_id']} | "
            f"{event['event_type']} | "
            f"{event['category']} | "
            f"{event['resolved_amount']} "
            f"{event['resolved_currency']} | "
            f"home={event['home_amount']} "
            f"{profile['home_currency']} | "
            f"{event['direction']} | "
            f"{event['status']} | "
            f"flex={event['flexibility']} | "
            f"{event['description']}"
        )

# ============================================================
# EVENT HOME-CURRENCY ENRICHMENT
# ============================================================

def enrich_events_with_home_amounts(
    events: list[dict],
    profiles: dict[str, dict],
    fx_index: dict[tuple[date, str, str], Decimal],
) -> None:
    """
    Add the event amount converted into the user's home currency.

    The conversion uses the exact event date and the supplied
    dated FX table.
    """

    for event in events:
        profile = profiles.get(event["user_id"])

        if profile is None:
            raise ValueError(
                f"No profile found for user {event['user_id']}"
            )

        home_currency = profile["home_currency"]

        event["home_amount"] = event_home_currency_amount(
            event=event,
            home_currency=home_currency,
            fx_index=fx_index,
        )

# ============================================================
# MAIN
# ============================================================

def main() -> None:
    validate_output_columns()

    data = load_datasets()
    validate_dataset_counts(data)

    profiles = normalize_profiles(
        data["financial_profiles"]
    )

    requests = normalize_requests(
        data["requests"]
    )

    events = normalize_events(
        data["financial_events"]
    )

    payment_options = normalize_payment_options(
        data["request_payment_options"]
    )

    messages = normalize_messages(
        data["messages"]
    )

    images = normalize_images(
        data["images"]
    )

    exchange_rates = normalize_exchange_rates(
        data["exchange_rates"]
    )

    fx_index = build_fx_index(exchange_rates)

    print("Loading and normalizing dataset...")

    enrich_events_with_home_amounts(
        events,
        profiles,
        fx_index,
    )

    indexes = build_indexes(
        profiles=profiles,
        requests=requests,
        events=events,
        payment_options=payment_options,
        messages=messages,
        images=images,
    )

    recurring_streams = build_recurring_streams(events)

    print(f"Profiles: {len(indexes['profiles'])}")
    print(f"Requests: {len(indexes['requests_by_id'])}")
    print(f"Events: {len(indexes['events_by_id'])}")
    print(
        f"Payment options: "
        f"{sum(len(v) for v in indexes['options_by_request'].values())}"
    )
    print(f"Messages: {len(messages)}")
    print(f"Images: {len(images)}")
    print(f"Exchange rates: {len(exchange_rates)}")
    print(f"Recurring streams: {len(recurring_streams)}")

    print("\nGenerating production decisions...")

    rows = []

    total_requests = len(requests)

    for index, request in enumerate(requests, start=1):
        request_id = request["request_id"]

        profile = indexes["profiles"].get(
            request["user_id"]
        )

        if profile is None:
            raise ValueError(
                f"Missing financial profile for "
                f"user {request['user_id']} "
                f"required by {request_id}"
            )

        row = solve_request(
            request=request,
            profile=profile,
            events_by_user=indexes["events_by_user"],
            recurring_streams=recurring_streams,
            messages_by_user=indexes["messages_by_user"],
            payment_options_by_request=indexes["options_by_request"],
            fx_index=fx_index,
        )

        rows.append(row)

        if index % 10 == 0 or index == total_requests:
            print(
                f"  Processed {index}/{total_requests} requests"
            )

    if len(rows) != 250:
        raise ValueError(
            f"Expected exactly 250 output rows, "
            f"got {len(rows)}"
        )

    # Validate exact output schema.
    for row in rows:
        if list(row.keys()) != OUTPUT_COLUMNS:
            raise ValueError(
                f"Invalid output columns for "
                f"{row.get('request_id')}: "
                f"{list(row.keys())}"
            )

    write_output(rows)

    output_path = ROOT / "output.csv"

    print("\n" + "=" * 80)
    print("PRODUCTION RUN COMPLETE")
    print("=" * 80)
    print(f"Rows generated: {len(rows)}")
    print(f"Output file: {output_path}")
    print(f"Output exists: {output_path.exists()}")

    status_counts = Counter(
        row["affordability_status"]
        for row in rows
    )

    method_counts = Counter(
        row["recommended_payment_method"]
        for row in rows
    )

    print("\nAffordability status:")
    for status, count in sorted(status_counts.items()):
        print(f"  {status}: {count}")

    print("\nRecommended payment method:")
    for method, count in sorted(method_counts.items()):
        print(f"  {method}: {count}")

    print("\nFirst 5 decisions:")
    for row in rows[:5]:
        print(
            f"  {row['request_id']} | "
            f"safe={row['amount_safe_to_pay']} | "
            f"status={row['affordability_status']} | "
            f"method={row['recommended_payment_method']}"
        )

    print("\nSUCCESS: output.csv generated.")



if __name__ == "__main__":
    main()