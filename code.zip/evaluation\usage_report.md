# Token Usage and Cost Analysis

## Final Full-Dataset Run

The final full-dataset run processed all 250 requests and produced `output.csv`.

- Model providers: None
- Models: None
- Model/API calls: 0
- Input tokens: 0
- Output tokens: 0
- Total tokens: 0
- Average tokens per request: 0
- Estimated total model/API cost: $0.00
- Estimated model/API cost per request: $0.00

## Per-Model Usage

No external model was used. The submitted solution performs the financial-state reconstruction, forecasting, affordability calculation, payment-plan selection, and output generation locally and deterministically.

| Provider | Model | Calls | Input Tokens | Output Tokens | Total Tokens | Estimated Cost |
|---|---|---:|---:|---:|---:|---:|
| None | None | 0 | 0 | 0 | 0 | $0.00 |

## Overall Totals

| Metric | Value |
|---|---:|
| Requests processed | 250 |
| Model/API calls | 0 |
| Input tokens | 0 |
| Output tokens | 0 |
| Total tokens | 0 |
| Average tokens per request | 0 |
| Estimated total cost | $0.00 |
| Estimated cost per request | $0.00 |

No API keys, credentials, or sensitive configuration values are included.
